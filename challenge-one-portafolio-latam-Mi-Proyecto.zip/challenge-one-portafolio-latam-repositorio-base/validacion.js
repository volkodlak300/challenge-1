//Haz tú validación en javascript acá

// Obtener el formulario
var formulario = document.forms['form'];

// Agregar un event listener para el evento submit del formulario
formulario.addEventListener('submit', function(event) {
    // Obtener los valores de los campos del formulario
    var nombre = formulario.nombre.value;
    var email = formulario.email.value;
    var asunto = formulario.asunto.value;
    var mensaje = formulario.mensaje.value;

    // Validar que todos los campos estén completos
    if (nombre === '' || email === '' || asunto === '' || mensaje === '') {
        // Si algún campo está vacío, prevenir el envío del formulario
        event.preventDefault();
        // Mostrar un mensaje de error
        alert('Por favor, complete todos los campos del formulario.');
    }
});
